package com.java.cars.model;

public enum Gender {
MALE , FEMALE
}
